A Voxel Christmas - Portable Version
=====================================

INSTRUCTIONS:
1. Extract this folder anywhere
2. Run VoxelChristmas.exe
3. Enjoy!

REQUIREMENTS:
- Windows 10 or Windows 11
- WebView2 Runtime (usually pre-installed on Windows 11)
  If you get an error, download from:
  https://developer.microsoft.com/microsoft-edge/webview2/

The application runs in fullscreen mode.
Press Alt+F4 or close the window to exit.

File size: ~1-5MB (very lightweight!)
